<div align="center">

<img src="assets/datapulse-banner.svg" alt="DataPulse — Student Performance and Academic Insights" width="100%" />

<p><b>Turn raw student data into clear, responsible insights.</b></p>

<img alt="Python" src="https://img.shields.io/badge/Python-3.10%2B-3776AB?style=for-the-badge&logo=python&logoColor=white" />
<img alt="Pandas" src="https://img.shields.io/badge/Pandas-Analysis-150458?style=for-the-badge&logo=pandas&logoColor=white" />
<img alt="Matplotlib" src="https://img.shields.io/badge/Matplotlib-Visuals-11557C?style=for-the-badge" />
<img alt="License MIT" src="https://img.shields.io/badge/License-MIT-22c55e?style=for-the-badge" />

<br/><br/>

**An interactive student analytics dashboard** exploring study time, attendance, score distributions, and correlations using Streamlit, Python, Pandas, and Matplotlib.

</div>

---

## ◈ Project overview

**DataPulse** takes a CSV dataset, validates the data, calculates descriptive metrics and correlations, groups scores into performance bands, and generates clean visual reports. It is designed as a portfolio-ready learning project with a simple command-line workflow.

> **Data ethics:** The bundled dataset is synthetic and contains no real student records. Correlation does not imply causation. Do not use this demo to evaluate real students.

## ✦ What it does

<table>
  <tr>
    <td width="50%">
      <h3>▦ Data validation</h3>
      Checks required columns, numeric values, empty files, and sensible score, attendance, and study-hour ranges.
    </td>
    <td width="50%">
      <h3>◉ Exploratory analysis</h3>
      Computes averages and Pearson correlations to help explore relationships in the sample.
    </td>
  </tr>
  <tr>
    <td width="50%">
      <h3>▥ Performance bands</h3>
      Groups scores into Needs Support, Developing, Good, and Excellent categories.
    </td>
    <td width="50%">
      <h3>⌁ Visual reports</h3>
      Exports a scatter plot, performance-band chart, correlation heatmap, and plain-text summary.
    </td>
  </tr>
</table>

## ⟡ Visual gallery

<div align="center">
  <table>
    <tr>
      <td align="center" width="50%">
        <b>Study time vs score</b><br/>
        <img src="outputs/study_vs_score.png" alt="Scatter plot of study time versus final score" width="100%"/>
      </td>
      <td align="center" width="50%">
        <b>Performance distribution</b><br/>
        <img src="outputs/performance_bands.png" alt="Bar chart showing student performance bands" width="100%"/>
      </td>
    </tr>
    <tr>
      <td align="center" colspan="2">
        <b>Correlation matrix</b><br/>
        <img src="outputs/correlation_matrix.png" alt="Correlation heatmap for study hours, attendance, and final score" width="75%"/>
      </td>
    </tr>
  </table>
</div>

## 🖥️ Launch the interactive frontend

    DataPulse includes a Streamlit dashboard with KPI cards, score and attendance filters, interactive CSV upload, charts, student records, and filtered CSV export.

    Install the dependencies (including Streamlit):

    ```bash
    python -m pip install -r requirements.txt
    ```

    Launch the web app from the project root:

    ```bash
    python -m streamlit run app.py
    ```

    Streamlit will print a local URL, usually `http://localhost:8501`, and may open it in your browser automatically. Keep the terminal running while you use the dashboard; press `Ctrl+C` in the terminal to stop it.

    ## ⚡ Run the command-line analysis
    

### 1. Clone the repository

```bash
git clone https://github.com/YOUR-USERNAME/DataPulse_Student_Insights.git
cd DataPulse_Student_Insights
```

Replace `YOUR-USERNAME` with your GitHub username and adjust the repository name if needed.

### 2. Create and activate a virtual environment

**Windows PowerShell**
```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
```

**macOS / Linux**
```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 3. Install dependencies and run

```bash
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python analyze.py
```

The script writes charts and `summary.txt` into `outputs/`. Existing output files are refreshed when you run it.

### Use a different CSV or output folder

```bash
python analyze.py --input data/student_performance.csv --output outputs
```

The CSV must contain these columns:

| Column | Meaning | Expected range |
|---|---|---|
| `student_id` | Synthetic or anonymized row identifier | Text |
| `study_hours_per_day` | Study hours per day | 0–24 |
| `attendance_percent` | Attendance percentage | 0–100 |
| `final_score` | Final score | 0–100 |

## 🧪 Run tests

```bash
python -m unittest discover -s tests -v
```

## 🗂️ Repository structure

```text
DataPulse_Student_Insights/
├── assets/
│   └── datapulse-banner.svg
├── data/
│   └── student_performance.csv
├── outputs/
│   ├── correlation_matrix.png
│   ├── performance_bands.png
│   ├── study_vs_score.png
│   └── summary.txt
├── tests/
│   └── test_analysis.py
├── .gitignore
├── LICENSE
├── analyze.py
├── README.md
└── requirements.txt
```

## 📌 How the analysis works

1. Load the CSV with Pandas.
2. Validate schema and numeric ranges.
3. Assign each score to a performance band.
4. Calculate descriptive statistics and Pearson correlations.
5. Export visualizations and a text summary.

**Performance bands:** Needs Support (below 40), Developing (40–59.99), Good (60–79.99), Excellent (80–100).

## 🧠 Key learning outcomes

- CSV ingestion and data quality checks
- Descriptive statistics with Pandas
- Correlation analysis and responsible interpretation
- Data categorization with `pandas.cut`
- Visual storytelling with Matplotlib
- Reusable Python functions, CLI arguments, and unit tests

## 🛣️ Possible next upgrades

- Add an interactive Streamlit dashboard with filters
- Compare multiple cohorts or semesters
- Add missing-value and outlier reports
- Export a formatted HTML/PDF report
- Add a model only after defining a valid research question and evaluation plan

## 🤝 Contributing

Contributions and improvements are welcome. For a change, create a branch, test it locally, and open a pull request with a short explanation.

## 📄 License

Distributed under the MIT License. See [`LICENSE`](LICENSE).

---

<div align="center">
  <sub>Built for learning • Designed for clarity • Interpret data responsibly</sub>
</div>
