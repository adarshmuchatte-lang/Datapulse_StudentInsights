from __future__ import annotations

from pathlib import Path
import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt

from analyze import REQUIRED_COLUMNS, add_performance_bands, load_data

BASE_DIR = Path(__file__).resolve().parent
DEFAULT_DATA = BASE_DIR / "data" / "student_performance.csv"

st.set_page_config(
    page_title="DataPulse | Student Insights",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""
<style>
    .stApp {
        background:
            radial-gradient(circle at 85% 4%, rgba(99,102,241,.17), transparent 28rem),
            radial-gradient(circle at 8% 16%, rgba(6,182,212,.10), transparent 25rem),
            #080e1b;
        color: #edf4ff;
    }
    [data-testid="stSidebar"] {
        background: linear-gradient(180deg, #0d1729 0%, #101a31 100%);
        border-right: 1px solid rgba(148,163,184,.16);
    }
    .hero {
        padding: 1.6rem 1.8rem;
        border: 1px solid rgba(129,140,248,.28);
        border-radius: 24px;
        background: linear-gradient(120deg, rgba(15,23,42,.96), rgba(30,41,82,.78));
        box-shadow: 0 18px 60px rgba(0,0,0,.20);
        margin-bottom: 1.2rem;
    }
    .eyebrow {
        color: #67e8f9;
        text-transform: uppercase;
        letter-spacing: .18em;
        font-size: .75rem;
        font-weight: 800;
    }
    .hero h1 { font-size: clamp(2.2rem, 4vw, 3.8rem); margin: .25rem 0; }
    .hero p { color: #cbd5e1; font-size: 1.04rem; margin-bottom: .2rem; }
    .metric-card {
        padding: 1rem 1.1rem;
        border-radius: 18px;
        background: rgba(15,23,42,.72);
        border: 1px solid rgba(148,163,184,.18);
        min-height: 115px;
    }
    .metric-label { color: #94a3b8; font-size: .82rem; }
    .metric-value { color: #f8fafc; font-size: 1.8rem; font-weight: 800; }
    .metric-note { color: #67e8f9; font-size: .76rem; }
    .section-title { font-size: 1.25rem; font-weight: 750; margin: .4rem 0 .8rem; }
    .note {
        border-left: 3px solid #22d3ee; padding: .7rem 1rem;
        background: rgba(8,145,178,.09); border-radius: 0 10px 10px 0;
        color: #cbd5e1; font-size: .9rem;
    }
    div[data-testid="stPlotlyChart"], div[data-testid="stDataFrame"] {
        border: 1px solid rgba(148,163,184,.14);
        border-radius: 16px;
        overflow: hidden;
    }
    .stButton button, .stDownloadButton button {
        border-radius: 12px;
    }
</style>
""", unsafe_allow_html=True)


def metric_card(label: str, value: str, note: str) -> None:
    st.markdown(
        f'<div class="metric-card"><div class="metric-label">{label}</div>'
        f'<div class="metric-value">{value}</div><div class="metric-note">{note}</div></div>',
        unsafe_allow_html=True,
    )


def make_chart(kind: str, frame: pd.DataFrame):
    fig, ax = plt.subplots(figsize=(8, 4.2), facecolor="#0f172a")
    ax.set_facecolor("#0f172a")
    ax.tick_params(colors="#cbd5e1")
    for spine in ax.spines.values():
        spine.set_color("#334155")
    ax.grid(True, color="#334155", alpha=.5, linewidth=.6)
    if kind == "scatter":
        ax.scatter(frame["study_hours_per_day"], frame["final_score"],
                   c=frame["attendance_percent"], cmap="cool", s=54, alpha=.85,
                   edgecolors="#e2e8f0", linewidths=.35)
        ax.set_xlabel("Study hours per day", color="#cbd5e1")
        ax.set_ylabel("Final score / 100", color="#cbd5e1")
        ax.set_title("Study time vs final score", color="#f8fafc", pad=12, weight="bold")
    elif kind == "bands":
        order = ["Needs Support", "Developing", "Good", "Excellent"]
        counts = frame["performance_band"].value_counts().reindex(order, fill_value=0)
        bars = ax.bar(counts.index, counts.values, color=["#f87171", "#fbbf24", "#60a5fa", "#34d399"], width=.62)
        ax.bar_label(bars, color="#f8fafc", padding=3)
        ax.set_ylim(0, max(1, int(counts.max() * 1.2)))
        ax.set_ylabel("Number of students", color="#cbd5e1")
        ax.set_title("Performance distribution", color="#f8fafc", pad=12, weight="bold")
        ax.tick_params(axis="x", rotation=12)
    else:
        corr = frame[["study_hours_per_day", "attendance_percent", "final_score"]].corr()
        im = ax.imshow(corr, vmin=-1, vmax=1, cmap="coolwarm")
        labels = ["Study hours", "Attendance", "Final score"]
        ax.set_xticks(range(3), labels, rotation=18, ha="right", color="#cbd5e1")
        ax.set_yticks(range(3), labels, color="#cbd5e1")
        for i in range(3):
            for j in range(3):
                ax.text(j, i, f"{corr.iloc[i, j]:.2f}", ha="center", va="center",
                        color="#0f172a" if abs(corr.iloc[i, j]) > .45 else "#f8fafc",
                        fontweight="bold")
        ax.set_title("Correlation matrix", color="#f8fafc", pad=12, weight="bold")
        fig.colorbar(im, ax=ax, fraction=.046, pad=.04)
    fig.tight_layout()
    return fig


st.markdown("""
<div class="hero">
  <div class="eyebrow">Student analytics · Interactive dashboard</div>
  <h1>DataPulse <span style="color:#67e8f9">↗</span></h1>
  <p>Find the signal in student performance data. Explore scores, attendance, study habits, and patterns in one place.</p>
</div>
""", unsafe_allow_html=True)

with st.sidebar:
    st.markdown("## ◈ DataPulse")
    st.caption("INSIGHTS CONSOLE · V1.0")
    st.markdown("---")
    st.markdown("### Load your data")
    uploaded = st.file_uploader("Upload a CSV file", type=["csv"], help="CSV must contain student_id, study_hours_per_day, attendance_percent, and final_score.")
    st.caption("No file uploaded? The bundled sample dataset will be used.")
    st.markdown("---")
    st.markdown("### Quick guide")
    st.markdown("- Explore the overview metrics\n- Filter the score range\n- Inspect charts and student rows\n- Download the filtered dataset")
    st.caption("Sample data is synthetic, not real student records.")

try:
    if uploaded is not None:
        raw = pd.read_csv(uploaded)
        missing = REQUIRED_COLUMNS - set(raw.columns)
        if missing:
            st.error("CSV is missing required columns: " + ", ".join(sorted(missing)))
            st.stop()
        # Reuse validation rules by writing only to an in-memory DataFrame path is unnecessary;
        # validate numeric fields and ranges here for uploaded data.
        for col in ["study_hours_per_day", "attendance_percent", "final_score"]:
            raw[col] = pd.to_numeric(raw[col], errors="coerce")
        if raw.empty or raw[["study_hours_per_day", "attendance_percent", "final_score"]].isna().any().any():
            st.error("The uploaded CSV is empty or contains invalid numeric values.")
            st.stop()
        if ((raw["study_hours_per_day"] < 0) | (raw["study_hours_per_day"] > 24)).any():
            st.error("Study hours must be between 0 and 24.")
            st.stop()
        for col in ["attendance_percent", "final_score"]:
            if ((raw[col] < 0) | (raw[col] > 100)).any():
                st.error(f"{col} must be between 0 and 100.")
                st.stop()
        data_source = uploaded.name
    else:
        raw = load_data(DEFAULT_DATA)
        data_source = "Bundled synthetic dataset"

    data = add_performance_bands(raw)
except Exception as exc:
    st.error(f"Could not load the dataset: {exc}")
    st.stop()

st.caption(f"DATA SOURCE  /  {data_source}  ·  {len(data):,} rows loaded")

min_score = int(max(0, data["final_score"].min()))
max_score = int(min(100, data["final_score"].max()))
with st.sidebar:
    score_range = st.slider(
        "Filter final score",
        min_value=0,
        max_value=100,
        value=(min_score, max_score),
        help="All overview metrics and charts update to match this score range.",
    )
    min_attendance = st.slider("Minimum attendance (%)", 0, 100, 0)

filtered = data[
    data["final_score"].between(score_range[0], score_range[1])
    & (data["attendance_percent"] >= min_attendance)
].copy()

if filtered.empty:
    st.warning("No rows match these filters. Adjust the score range or attendance threshold.")
    st.stop()

c1, c2, c3, c4 = st.columns(4)
with c1:
    metric_card("STUDENTS ANALYSED", f"{len(filtered):,}", f"of {len(data):,} total rows")
with c2:
    metric_card("AVERAGE FINAL SCORE", f"{filtered['final_score'].mean():.1f}", "out of 100")
with c3:
    metric_card("AVERAGE ATTENDANCE", f"{filtered['attendance_percent'].mean():.1f}%", "attendance rate")
with c4:
    metric_card("AVG. STUDY TIME", f"{filtered['study_hours_per_day'].mean():.1f}h", "per day")

st.markdown("")
left, right = st.columns([1.25, 1])
with left:
    st.markdown('<div class="section-title">◌ Study habits & outcomes</div>', unsafe_allow_html=True)
    st.pyplot(make_chart("scatter", filtered), use_container_width=True)
with right:
    st.markdown('<div class="section-title">▥ Performance bands</div>', unsafe_allow_html=True)
    st.pyplot(make_chart("bands", filtered), use_container_width=True)

st.markdown('<div class="section-title">⌁ Relationship explorer</div>', unsafe_allow_html=True)
st.pyplot(make_chart("corr", filtered), use_container_width=True)

corr = filtered[["study_hours_per_day", "attendance_percent", "final_score"]].corr()["final_score"]
st.markdown(
    f'<div class="note">In this filtered dataset, Pearson correlation with final score is '
    f'<b>{corr["study_hours_per_day"]:.2f}</b> for study hours and '
    f'<b>{corr["attendance_percent"]:.2f}</b> for attendance. Correlation describes association, not causation.</div>',
    unsafe_allow_html=True,
)

st.markdown("")
st.markdown('<div class="section-title">▤ Student records</div>', unsafe_allow_html=True)
show_bands = st.multiselect(
    "Show performance bands",
    ["Needs Support", "Developing", "Good", "Excellent"],
    default=["Needs Support", "Developing", "Good", "Excellent"],
)
table = filtered[filtered["performance_band"].astype(str).isin(show_bands)]
st.dataframe(table, use_container_width=True, hide_index=True)
st.download_button(
    "⬇ Download filtered data as CSV",
    data=table.to_csv(index=False).encode("utf-8"),
    file_name="datapulse_filtered_students.csv",
    mime="text/csv",
)
st.markdown("")
st.caption("DataPulse · Built with Python, Pandas, Matplotlib, and Streamlit · Synthetic demo data only")
