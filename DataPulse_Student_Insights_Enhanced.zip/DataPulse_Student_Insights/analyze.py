"""DataPulse: Student Performance & Academic Insights.

Run from any directory with:
    python analyze.py
Optional:
    python analyze.py --input data/student_performance.csv --output outputs
The bundled dataset is synthetic and for educational demonstration only.
"""
from __future__ import annotations

import argparse
from pathlib import Path
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

REQUIRED_COLUMNS = {"student_id", "study_hours_per_day", "attendance_percent", "final_score"}
BAND_ORDER = ["Needs Support", "Developing", "Good", "Excellent"]
BAND_BINS = [-0.001, 39.999, 59.999, 79.999, 100.001]


def parse_args() -> argparse.Namespace:
    base = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description="Explore synthetic student performance data.")
    parser.add_argument("--input", type=Path, default=base / "data" / "student_performance.csv",
                        help="Path to input CSV (default: bundled sample dataset).")
    parser.add_argument("--output", type=Path, default=base / "outputs",
                        help="Directory for generated charts and summary.")
    return parser.parse_args()


def load_data(path: Path) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(f"Input CSV not found: {path}")
    frame = pd.read_csv(path)
    missing = REQUIRED_COLUMNS - set(frame.columns)
    if missing:
        raise ValueError("CSV is missing required column(s): " + ", ".join(sorted(missing)))
    if frame.empty:
        raise ValueError("Input CSV has no rows.")
    for col in ["study_hours_per_day", "attendance_percent", "final_score"]:
        frame[col] = pd.to_numeric(frame[col], errors="coerce")
    if frame[["study_hours_per_day", "attendance_percent", "final_score"]].isna().any().any():
        raise ValueError("Study hours, attendance, and final score must contain valid numeric values.")
    if ((frame["study_hours_per_day"] < 0) | (frame["study_hours_per_day"] > 24)).any():
        raise ValueError("Study hours per day must be between 0 and 24.")
    for col in ["attendance_percent", "final_score"]:
        if ((frame[col] < 0) | (frame[col] > 100)).any():
            raise ValueError(f"{col} must be between 0 and 100.")
    return frame


def add_performance_bands(frame: pd.DataFrame) -> pd.DataFrame:
    result = frame.copy()
    result["performance_band"] = pd.cut(
        result["final_score"],
        bins=[-0.001, 39.999, 59.999, 79.999, 100.001],
        labels=BAND_ORDER,
        include_lowest=True,
    )
    return result


def make_charts(frame: pd.DataFrame, output_dir: Path) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    plt.style.use("seaborn-v0_8-whitegrid")

    fig, ax = plt.subplots(figsize=(9, 5.5))
    ax.scatter(frame["study_hours_per_day"], frame["final_score"], alpha=0.78, edgecolors="white", linewidths=0.5)
    ax.set(title="Study Time vs Final Score", xlabel="Study hours per day", ylabel="Final score (out of 100)")
    fig.text(0.99, 0.01, "Synthetic demonstration data", ha="right", fontsize=8, color="dimgray")
    fig.tight_layout()
    fig.savefig(output_dir / "study_vs_score.png", dpi=180, bbox_inches="tight")
    plt.close(fig)

    band_counts = frame["performance_band"].value_counts().reindex(BAND_ORDER, fill_value=0)
    fig, ax = plt.subplots(figsize=(9, 5.5))
    bars = ax.bar(band_counts.index.astype(str), band_counts.values)
    ax.bar_label(bars, padding=3)
    ax.set(title="Student Performance Bands", xlabel="Performance band", ylabel="Number of students")
    ax.set_ylim(0, max(1, int(band_counts.max() * 1.18)))
    fig.tight_layout()
    fig.savefig(output_dir / "performance_bands.png", dpi=180, bbox_inches="tight")
    plt.close(fig)

    corr = frame[["study_hours_per_day", "attendance_percent", "final_score"]].corr()
    fig, ax = plt.subplots(figsize=(7, 5.5))
    image = ax.imshow(corr, vmin=-1, vmax=1, cmap="coolwarm")
    ax.set_xticks(range(len(corr.columns)), ["Study hours", "Attendance", "Final score"], rotation=25, ha="right")
    ax.set_yticks(range(len(corr.index)), ["Study hours", "Attendance", "Final score"])
    for i in range(len(corr.index)):
        for j in range(len(corr.columns)):
            ax.text(j, i, f"{corr.iloc[i, j]:.2f}", ha="center", va="center", color="black")
    ax.set_title("Correlation Matrix")
    fig.colorbar(image, ax=ax, label="Pearson correlation")
    fig.tight_layout()
    fig.savefig(output_dir / "correlation_matrix.png", dpi=180, bbox_inches="tight")
    plt.close(fig)


def write_summary(frame: pd.DataFrame, output_dir: Path) -> None:
    corr = frame[["study_hours_per_day", "attendance_percent", "final_score"]].corr()["final_score"]
    counts = frame["performance_band"].value_counts().reindex(BAND_ORDER, fill_value=0)
    lines = [
        "DATAPULSE — ANALYSIS SUMMARY",
        "",
        "Dataset note: synthetic demonstration data; not real student records.",
        "Correlation indicates association, not causation.",
        "",
        f"Rows analysed: {len(frame)}",
        f"Average final score: {frame['final_score'].mean():.1f}/100",
        f"Average study hours/day: {frame['study_hours_per_day'].mean():.1f}",
        f"Average attendance: {frame['attendance_percent'].mean():.1f}%",
        "",
        "Correlation with final score (Pearson r):",
        f"- Study hours: {corr['study_hours_per_day']:.2f}",
        f"- Attendance: {corr['attendance_percent']:.2f}",
        "",
        "Performance band counts:",
    ]
    lines.extend(f"- {band}: {int(counts[band])}" for band in BAND_ORDER)
    lines.extend([
        "",
        "Interpretation:",
        "These figures describe only this dataset. They do not establish that study time or attendance causes a particular score.",
        "Do not use this demonstration dataset to assess or make decisions about real students.",
        "",
    ])
    (output_dir / "summary.txt").write_text("\n".join(lines), encoding="utf-8")


def main() -> int:
    args = parse_args()
    try:
        frame = add_performance_bands(load_data(args.input))
        make_charts(frame, args.output)
        write_summary(frame, args.output)
    except (FileNotFoundError, ValueError, pd.errors.ParserError) as exc:
        print(f"DataPulse error: {exc}", file=sys.stderr)
        return 1

    corr = frame[["study_hours_per_day", "attendance_percent", "final_score"]].corr()["final_score"]
    print("\nDATAPULSE | STUDENT INSIGHTS")
    print("=" * 32)
    print(f"Rows analysed:              {len(frame)}")
    print(f"Average final score:        {frame['final_score'].mean():.1f}/100")
    print(f"Average study hours/day:    {frame['study_hours_per_day'].mean():.1f}")
    print(f"Average attendance:         {frame['attendance_percent'].mean():.1f}%")
    print(f"Study hours ↔ final score:  r = {corr['study_hours_per_day']:.2f}")
    print(f"Attendance ↔ final score:   r = {corr['attendance_percent']:.2f}")
    print(f"\nCharts and summary saved in: {args.output.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
