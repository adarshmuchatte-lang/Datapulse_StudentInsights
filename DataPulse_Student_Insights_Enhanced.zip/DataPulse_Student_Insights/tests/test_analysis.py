import unittest
import pandas as pd
from analyze import add_performance_bands, load_data


class DataPulseTests(unittest.TestCase):
    def test_performance_bands_cover_boundaries(self):
        frame = pd.DataFrame({
            "student_id": ["a", "b", "c", "d", "e"],
            "study_hours_per_day": [1, 1, 1, 1, 1],
            "attendance_percent": [50, 50, 50, 50, 50],
            "final_score": [0, 39.9, 40, 80, 100],
        })
        result = add_performance_bands(frame)
        self.assertEqual(str(result.loc[0, "performance_band"]), "Needs Support")
        self.assertEqual(str(result.loc[2, "performance_band"]), "Developing")
        self.assertEqual(str(result.loc[3, "performance_band"]), "Excellent")

    def test_load_bundled_dataset(self):
        from pathlib import Path
        frame = load_data(Path(__file__).resolve().parents[1] / "data" / "student_performance.csv")
        self.assertGreater(len(frame), 0)
        self.assertTrue(frame["final_score"].between(0, 100).all())


if __name__ == "__main__":
    unittest.main()
